DOSSIER DE CLÔTURE FIDUCIAIRE ZENTRA
=====================================

Statut du paquet : DRAFT
Exercice : Recette 2026 (2026-01-01 au 2026-12-31)
Créé le : 2026-09-10T04:18:57.879881700+00:00
Version Zentra : 1.46.1
Empreinte source SHA-256 : 228115725185c3f60a5186334f7b8e97a690bd979e5157fa4e71c8f5ba026f82

PORTÉE DU STATUT
DRAFT signifie que l'exercice n'est pas verrouillé ou que la revue comporte un blocage.
FINAL signifie uniquement que l'exercice local était verrouillé et que les contrôles
techniques figés étaient prêts lors de l'export.

INTÉGRITÉ
manifest.json contient la taille et l'empreinte exacte de chaque fichier de données.
SHA256SUMS ajoute l'empreinte exacte du manifeste. Il s'exclut lui-même afin d'éviter
une dépendance circulaire. Les CSV sont UTF-8 avec BOM, séparés par des virgules et
protègent les cellules textuelles commençant comme une formule de tableur. Les montants
sont des centimes entiers en CHF.

L'audit contenu dans le ZIP est l'instantané vérifié juste avant l'enregistrement de
cet export; l'événement d'export est ajouté à la base locale après fixation des octets.

LIMITES
Ce dossier facilite la revue et la conservation locale des données comptables. Il ne constitue ni une certification, ni une garantie de conformité légale, fiscale ou professionnelle. L'entreprise reste responsable de la clôture, de l'annexe, des décisions d'approbation, de la conservation durable et de la validation par les personnes compétentes.
