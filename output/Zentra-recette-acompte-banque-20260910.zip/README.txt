Zentra - Recette fictive acompte et banque - 10 septembre 2026

Commencer par compte-rendu.md. Les quatre PDF de pieces/ sont des exports natifs fictifs.
Le ZIP de clôture natif et la sauvegarde sont dans pieces/. Les XML sont des relevés synthétiques.
Les calculs et le rejeu passent. Les trop-perçus et le traitement temporel des avances restent ouverts.
Aucune validation XSD, professionnelle, bancaire réelle ou sur appareil physique n’est acquise.
SHA256SUMS permet de vérifier chaque membre de cette archive.
